# Onboarding-plan for nyansatt

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Vi har ansatt noen. Lag onboarding-planen for de første tretti dagene.»

Fortell hvem som er ansatt, i hvilken rolle, hvem de jobber med, og hva de skal kunne gjøre alene etter en måned. Si også hva som pleier å gå galt hos dere.

Send planen til den nye på forhånd. Det er halve verdien.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
