# Månedstallene i klartekst

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Her er månedens resultatrapport. Forklar den i klartekst.»

Lim inn tallene. Resultatrapport, hovedbokutdrag eller et regneark fungerer. Ta med forrige måned eller budsjettet hvis du har det, ellers har den ingenting å sammenligne med.

Si hvem som skal lese det. En styreleder og en avdelingsleder trenger ikke det samme.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
