# Gjennomlesing av avtale

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Her er en avtale jeg skal signere. Gå gjennom den for meg.»

Lim inn avtalen, inkludert vedlegg og henvisninger til standardvilkår hvis du har dem. Si hvilken part du er.

Ta punktene under «Bør avklares før signering» med tilbake til motparten. Det er en normal del av en forhandling.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
