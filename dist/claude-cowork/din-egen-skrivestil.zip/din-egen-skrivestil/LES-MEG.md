# Din egen skrivestil

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Her er åtte tekster jeg har skrevet selv. Lag stilprofilen min.»

Finn åtte tekster du har skrevet selv og som du er fornøyd med. Blandet lengde og situasjon gir best resultat: to e-poster til en kunde, to interne meldinger, et lengre notat, en beskjed du sendte da du var stresset, noe du skrev til en du kjenner godt, og noe formelt.

Ikke rens dem. Skrivefeil, halve setninger og rare uttrykk er nettopp det som gjør profilen din til din.

Lim dem inn og be om stilprofilen. Legg svaret inn som fast instruks i verktøyet, så gjelder det videre.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
