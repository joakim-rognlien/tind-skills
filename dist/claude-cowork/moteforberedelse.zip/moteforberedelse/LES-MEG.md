# Møteforberedelse på ti minutter

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Jeg skal i møte med dette selskapet. Her er nettsiden og e-postene våre så langt.»

Lim inn det du har: lenken til nettsiden deres, tidligere e-poster, notater fra forrige møte, siste årsrapport hvis du har den. Si hvem du skal møte og hva slags møte det er.

Bruk spørsmålene som utgangspunkt, ikke manus. Poenget er å ha tenkt før du går inn.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
