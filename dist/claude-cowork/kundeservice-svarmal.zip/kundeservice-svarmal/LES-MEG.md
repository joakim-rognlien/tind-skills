# Svarbibliotek fra egne henvendelser

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Her er de siste hundre henvendelsene våre. Bygg svarbiblioteket.»

Lim inn henvendelser fra innboksen, chatten eller skjemaet deres. Femti er nok, hundre er bedre. Fjern navn og personopplysninger før du limer inn.

Har du svar dere allerede bruker, ta dem med. Da bygger den videre på det som finnes.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
