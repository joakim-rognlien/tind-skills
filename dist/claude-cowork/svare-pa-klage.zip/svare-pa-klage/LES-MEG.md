# Svaret på den vanskelige e-posten

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Her er e-posten jeg har fått. Hjelp meg å svare.»

Lim inn e-posten du har fått, og skriv i én setning hva som faktisk har skjedd sett fra din side. Ta med om noe er lovet tidligere.

Velg utkast, les gjennom, og send det som deg selv. Ikke send noe du ikke ville sagt høyt.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
