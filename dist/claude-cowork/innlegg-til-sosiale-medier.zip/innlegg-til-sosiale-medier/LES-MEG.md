# Én sak, ti innlegg

## Slik tar du den i bruk i Claude Cowork

1. Åpne Claude og gå til Customize (Tilpass), deretter fanen Skills (Ferdigheter).
2. Klikk Add og velg zip-fila du lastet ned.
3. Skru skillen på i samme liste.
4. Skriv en melding som handler om oppgaven. Claude henter skillen selv når den passer.
5. Står menyen på et annet språk enn her, er det samme sted. Grensesnittet oversettes, funksjonen er den samme.

Startprompt: «Her er artikkelen. Lag distribusjonspakken.»

Lim inn artikkelen, kundehistorien eller rapporten. Si hvem du snakker til og hvilke kanaler du bruker.

Har du en stilprofil fra «Din egen skrivestil», legg den inn først. Da høres innleggene ut som deg og ikke som markedsavdelingen.

---
Laget av Tind Studio. Fri å bruke og endre internt i din egen virksomhet.
Versjon 1.0, sist testet 2026-09-05. tindstudio.no
